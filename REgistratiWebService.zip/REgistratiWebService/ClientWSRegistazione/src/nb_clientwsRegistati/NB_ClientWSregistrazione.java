/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nb_clientwsRegistrazione;

/**
 *
 * @author Romano_Luca
 */
public class NB_ClientWSRegistrati {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String ris=Login("pietro","cappio","pippo","ciao","pippo12@libero.it");
        
        if(ris.compareTo("ok")==0)
            System.out.println("Registrazione avvenuta con successo");
        else
              System.out.println("inserimento errato");
    }

    private static String Login(java.lang.String nome,java.lang.String cognome,java.lang.String username, java.lang.String password,java.lang.String email) {
        org.romano.Rws.RegistratiWebService service = new org.romano.loginws.RegistratiWebService();
        org.romano.Rws.RegistratiWS port = service.getPortaRegistrati();
        return port.checkRegistrati(nome,cognome,username, password,email);
    }
    
}
