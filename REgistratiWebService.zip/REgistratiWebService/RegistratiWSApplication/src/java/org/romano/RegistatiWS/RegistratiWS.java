/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.romano.RegistratiWS;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Romano_Luca
 */
@WebService(serviceName = "RegistratiWS")
public class LoginWS {


    
    @WebMethod(operationName = "Registraziome")
    public String checkRegistrati(@WebParam(name = "nome") String nome, @WebParam(name = "cognome") String cognome,@WebParam(name = "username") String username, @WebParam(name = "password") String password,@WebParam(name = "email") String email) {
        String ris="";
        
        if(nome.compareTo("pietro")==0 && cognome.compareTo("cappio")==0 &&  username.compareTo("pippo")==0 && password.compareTo("ciao")==0,email.compareTo("pippo1@libero.it")==0 && )
        {
            ris="ok";
        } 
        else {
            ris="no";
        }
        return ris;
    }
}
